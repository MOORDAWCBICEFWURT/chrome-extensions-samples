"""Extensions for the bot.

See: https://hikari-lightbulb.readthedocs.io/en/latest/guides/extensions.html
"""

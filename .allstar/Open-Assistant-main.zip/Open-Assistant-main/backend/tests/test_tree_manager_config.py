from oasst_backend.config import TreeManagerConfiguration


def test_tree_manager_config():
    """
    Just test that we can create a config
    """
    TreeManagerConfiguration()

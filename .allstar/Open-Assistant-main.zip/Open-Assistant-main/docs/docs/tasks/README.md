# Tasks

Understand a bit more about each type of task required to build the Open
Assistant dataset.

- [Classifying an assistant reply](label_assistant_reply.md)
- [Classifying an initial prompt of user reply](label_prompter_reply.md)
- [Providing an assistant reply](reply_as_assistant.md)
- [Providing an initial prompt or user reply](reply_as_user.md)
- [Ranking assistant replies](rank_assistant_replies.md)

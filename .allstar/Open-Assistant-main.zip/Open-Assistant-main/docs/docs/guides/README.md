# Guides

Useful guides for Open Assistant:

- [General guidelines for using open-assistant.io](https://projects.laion.ai/Open-Assistant/docs/guides/guidelines)
- [Example responses](https://projects.laion.ai/Open-Assistant/docs/guides/examples)
- [Developer guide, contains a lot of technical info](https://projects.laion.ai/Open-Assistant/docs/guides/developers)

# Data

Resources related to data:

- [Data schemas](https://projects.laion.ai/Open-Assistant/docs/data/schemas)
- [Datasets](https://projects.laion.ai/Open-Assistant/docs/data/datasets)
- [Data augmentation](https://projects.laion.ai/Open-Assistant/docs/data/augmentation)
- [Supervised datasets](https://projects.laion.ai/Open-Assistant/docs/data/supervised-datasets)

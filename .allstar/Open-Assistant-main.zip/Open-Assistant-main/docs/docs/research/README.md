# Research

Useful research materials:

- [General](https://projects.laion.ai/Open-Assistant/docs/research/general)
- [Cohere Grounded QA](https://projects.laion.ai/Open-Assistant/docs/research/search-based-qa)

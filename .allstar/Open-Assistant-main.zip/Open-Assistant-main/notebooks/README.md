# Deprecated

This `notebooks` directory is being retired in favour of new dataset
contributions going to the `data/datasets` directory, following the guidelines
[here](https://github.com/LAION-AI/Open-Assistant/blob/main/data/datasets/README.md).
Please do not submit future data notebooks here.

## Notebooks

This directory was designed to hold notebooks, primarily for data scraping and
augmentation.

# Hippocorpus Converter

This notebook takes an existing copy of the
[Hippocorpus](https://huggingface.co/datasets/hippocorpus) and augments it for
training OpenAssistant. **This notebook is currently unique among its peers in
the same folder as it requires an existing copy of the Hippocorpus. See the
above HuggingFace link for a download link.**

#!/bin/bash

docker compose run --rm certbot renew

# OpenAssistant Inference Safety Server

Basic FastAPI server to serve safety models using
[Blade2Blade](https://github.com/LAION-AI/blade2blade/).

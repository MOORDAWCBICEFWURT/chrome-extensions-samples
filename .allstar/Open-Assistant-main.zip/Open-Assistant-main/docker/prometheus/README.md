# Prometheus

[Prometheus](https://github.com/prometheus/prometheus) is an open source
monitoring system.

This folder contains some configfuration files used to set up Prometheus.

- [`./prometheus.yml`](./prometheus.yml) - Config for Prometheus, including what
  `/metrics` endpoints to scrape.

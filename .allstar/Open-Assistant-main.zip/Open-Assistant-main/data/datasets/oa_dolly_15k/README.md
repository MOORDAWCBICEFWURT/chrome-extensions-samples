See the [Dolly repo](https://github.com/databrickslabs/dolly/tree/master/data)
for information on this dataset.

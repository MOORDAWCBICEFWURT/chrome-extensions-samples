---
license: mit
language:
  - th
tags:
  - Open Assistant
task_categories:
  - question-answering
  - text-generation
---

This dataset is fork from
[https://huggingface.co/datasets/iapp_wiki_qa_squad](https://huggingface.co/datasets/iapp_wiki_qa_squad)
that made for Open Assistant.

Pull request:
[Add iapp_wiki_qa_squad to datasets #1903 ](https://github.com/LAION-AI/Open-Assistant/pull/1903)

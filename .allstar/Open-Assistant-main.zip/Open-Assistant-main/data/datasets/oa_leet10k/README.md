# oa_leet10k datasets

Here we convert oa_leet10k dataset to be uploaded to huggingface.

## oa_leet10k.ipynb

Takes this Kaggle dataset 'leetcode-solutions'
https://www.kaggle.com/datasets/erichartford/leetcode-solutions, and turns them
into basic dialogue using a preset list of user prompt tempaltes.

### Some ideas for extending this dataset

The solutions need to be verified.

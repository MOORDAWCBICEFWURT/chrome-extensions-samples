# NSFW - CSAM from Reddit

Note(TODO): this is the pipeline, will need to scale this dataset by getting
data from file.pushshift.io The scripts and notebooks in the directory are used
to create the NSFW and CSAM dataset from Reddit that can be used to train the
safety model.
